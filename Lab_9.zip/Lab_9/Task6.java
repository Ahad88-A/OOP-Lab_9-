import java.util.Random;


class Task6{

	public static void main(String[] args) {
		
		int count[]= new int[21];
		
		Random rand=new Random();

		
		for(int i=0;i<100;i++){
		
			int num = rand.nextInt(21);
		
			count[num]++;
		}

		
		for(int i=0;i<=20;i++){
		
			System.out.println("Number " + i + ": " + count[i] + " times");
		}

	}
	
}